# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from models import *
from django.shortcuts import render, redirect, HttpResponseRedirect, reverse
from django.contrib import messages
import bcrypt

def index(request):
    return render(request, "index.html")

def create(request):
    errors = Users.objects.register_validator(request.POST)
    if len(errors):
        for tag, error in errors.iteritems():
            messages.error(request, error, extra_tags=tag)
        return redirect('/')
    else:
        messages.success(request,"You have logged in!")
        current_user = Users.objects.get(email = request.POST['email'])
        request.session['user_id'] = current_user.id
        print "user was created"
        return redirect('/success')
    print "user was able to create profile"

def success(request):
    print "welcome user to profile page"
    current_user = Users.objects.get(id=request.session['user_id'])
    try:
        users = Users.object.all()
        user = []
        for user in users:
            if(Users.id != request.session['user_id']):
                user.append(user)
    except: 
        users = None
    try:
        friend = Friends.objects.filter(user_friend=current_user)
        current_users_friend = []
        for current_users_friend in friends:
            current_users_friend.append(current_users_friend.second_friend)
        not_friends_with = []
        for not_friends_with in user:
            if user not in not_friends_with:
                not_friends_with.appead(user)
    except:
        friends = None
    context = {
        'users': Users.objects.all(),
        'current_user': Users.objects.get(id=request.session['user_id']),
        'friends': current_users_friend,
        #  'users': Friends.objects.all()
    }
    return render(request,"success.html", context)

def show(request, user_id):
    print "user made it to show profile page"
    context = {
        'current_user': Users.objects.get(id=user_id)
    }
    return render(request, "show.html", context)

def add(self,friends_id, user_id):
    current_user = self.get(id=user_id)
    friend = Friends.objects.get(id=friends_id)
    Friends.objects.create(user_friend=current_user, second_friend=friend)
    Friends.objects.create(user_friend=friend,second_friend=current_user)

def delete(request, user_id):
    Users.objects.get(id=user_id).delete()
    return redirect('/')

def login(request):
    print "show page working"
    errors = Users.objects.login_validator(request.POST)
    if len(errors):
        for tag, error in errors.iteritems():
            messages.error(request, error)            
            return redirect('/')
    else:
        current_user = Users.objects.get(email=request.POST['email'])
        request.session['user_id']= current_user.id
        return redirect('/success')
    print "user was able to login"

def logout(request):
    request.session.clear()
    return redirect('/')